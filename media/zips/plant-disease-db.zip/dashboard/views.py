from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from data_management.models import ImageData, TableData, ZipData
from django.db.models import Q

@login_required
def index(request):
    search_query = request.GET.get('search', '')
    crop_type = request.GET.get('crop_type', '')
    uploader = request.GET.get('uploader', '')
    
    # 基础查询
    image_query = ImageData.objects.all()
    table_query = TableData.objects.all()
    zip_query = ZipData.objects.all()
    
    # 搜索过滤
    if search_query:
        image_query = image_query.filter(
            Q(name__icontains=search_query) | 
            Q(region__icontains=search_query) | 
            Q(uploader__username__icontains=search_query)
        )
        table_query = table_query.filter(
            Q(name__icontains=search_query) | 
            Q(region__icontains=search_query) | 
            Q(uploader__username__icontains=search_query)
        )
        zip_query = zip_query.filter(
            Q(name__icontains=search_query) | 
            Q(region__icontains=search_query) | 
            Q(uploader__username__icontains=search_query)
        )
    
    # 作物类型过滤
    if crop_type:
        image_query = image_query.filter(crop_type=crop_type)
        table_query = table_query.filter(crop_type=crop_type)
        zip_query = zip_query.filter(crop_type=crop_type)
    
    # 上传人过滤
    if uploader:
        image_query = image_query.filter(uploader__username=uploader)
        table_query = table_query.filter(uploader__username=uploader)
        zip_query = zip_query.filter(uploader__username=uploader)
    
    context = {
        'images': image_query.order_by('-upload_time'),
        'tables': table_query.order_by('-upload_time'),
        'zips': zip_query.order_by('-upload_time'),
        'search_query': search_query,
        'crop_type': crop_type,
        'uploader': uploader,
    }
    
    return render(request, 'dashboard/index.html', context)

