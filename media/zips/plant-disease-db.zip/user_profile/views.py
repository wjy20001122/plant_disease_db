from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .forms import UserProfileForm, UserPasswordForm
from django.contrib import messages
from authentication.models import User
from django.contrib.auth.decorators import user_passes_test

@login_required
def profile(request):
    if request.method == 'POST':
        form = UserProfileForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, '个人资料更新成功')
            return redirect('user_profile:profile')
    else:
        form = UserProfileForm(instance=request.user)
    return render(request, 'user_profile/profile.html', {'form': form})

@login_required
def change_password(request):
    if request.method == 'POST':
        form = UserPasswordForm(request.POST)
        if form.is_valid():
            if request.user.check_password(form.cleaned_data.get('old_password')):
                request.user.set_password(form.cleaned_data.get('new_password'))
                request.user.save()
                messages.success(request, '密码修改成功，请重新登录')
                return redirect('authentication:login')
            else:
                messages.error(request, '原密码错误')
        else:
            messages.error(request, '表单填写有误')
    else:
        form = UserPasswordForm()
    return render(request, 'user_profile/change_password.html', {'form': form})

@user_passes_test(lambda u: u.is_admin())
def user_management(request):
    users = User.objects.all()
    return render(request, 'user_profile/user_management.html', {'users': users})

@user_passes_test(lambda u: u.is_admin())
def add_user(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        user_type = request.POST.get('user_type')
        
        if User.objects.filter(username=username).exists():
            messages.error(request, '用户名已存在')
        else:
            user = User.objects.create_user(
                username=username,
                email=email,
                password=password,
                user_type=user_type
            )
            messages.success(request, '用户添加成功')
            return redirect('user_profile:user_management')
    
    return render(request, 'user_profile/add_user.html')

@user_passes_test(lambda u: u.is_admin())
def delete_user(request, user_id):
    if request.user.id == user_id:
        messages.error(request, '不能删除自己的账户')
    else:
        user = User.objects.get(id=user_id)
        user.delete()
        messages.success(request, '用户删除成功')
    
    return redirect('user_profile:user_management')

@user_passes_test(lambda u: u.is_admin())
def change_user_type(request, user_id):
    if request.user.id == user_id:
        messages.error(request, '不能修改自己的权限')
    else:
        user = User.objects.get(id=user_id)
        user.user_type = 'admin' if user.user_type == 'regular' else 'regular'
        user.save()
        messages.success(request, '用户权限修改成功')
    
    return redirect('user_profile:user_management')

