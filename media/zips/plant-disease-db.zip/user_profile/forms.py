from django import forms
from authentication.models import User

class UserProfileForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ('username', 'email', 'phone')
        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'phone': forms.TextInput(attrs={'class': 'form-control'}),
        }

class UserPasswordForm(forms.Form):
    old_password = forms.CharField(label='原密码', widget=forms.PasswordInput(attrs={'class': 'form-control'}))
    new_password = forms.CharField(label='新密码', widget=forms.PasswordInput(attrs={'class': 'form-control'}))
    confirm_password = forms.CharField(label='确认新密码', widget=forms.PasswordInput(attrs={'class': 'form-control'}))
    
    def clean_confirm_password(self):
        new_password = self.cleaned_data.get('new_password')
        confirm_password = self.cleaned_data.get('confirm_password')
        if new_password and confirm_password and new_password != confirm_password:
            raise forms.ValidationError('两次输入的密码不一致')
        return confirm_password

