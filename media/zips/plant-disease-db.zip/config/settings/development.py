"""
开发环境设置
"""
from .base import *

# 调试模式
DEBUG = True

# 允许的主机
ALLOWED_HOSTS = ['localhost', '127.0.0.1']

# 额外的开发应用
INSTALLED_APPS += [
    'debug_toolbar',
]

# 额外的开发中间件
MIDDLEWARE += [
    'debug_toolbar.middleware.DebugToolbarMiddleware',
]

# Debug Toolbar设置
INTERNAL_IPS = ['127.0.0.1']

# 邮件设置
EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'

# 简化密码验证
AUTH_PASSWORD_VALIDATORS = []

# 开发环境下的CORS设置
CORS_ALLOW_ALL_ORIGINS = True

# 开发环境下的REST Framework设置
REST_FRAMEWORK['DEFAULT_THROTTLE_RATES'] = {
    'anon': '1000/day',
    'user': '10000/day',
}

# 开发环境下的文件上传设置
FILE_UPLOAD_MAX_MEMORY_SIZE = 100 * 1024 * 1024  # 100 MB
DATA_UPLOAD_MAX_MEMORY_SIZE = 100 * 1024 * 1024  # 100 MB
MAX_UPLOAD_SIZE = 500 * 1024 * 1024  # 500 MB

