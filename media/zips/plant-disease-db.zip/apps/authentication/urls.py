"""
认证应用URL配置
"""
from django.urls import path
from . import views

app_name = 'authentication'

urlpatterns = [
    # 登录
    path('login/', views.LoginView.as_view(), name='login'),
    # 注册
    path('register/', views.RegisterView.as_view(), name='register'),
    # 登出
    path('logout/', views.LogoutView.as_view(), name='logout'),
    # 密码重置
    path('password-reset/', views.PasswordResetView.as_view(), name='password_reset'),
    path('password-reset/done/', views.PasswordResetDoneView.as_view(), name='password_reset_done'),
    # 密码修改
    path('password-change/', views.PasswordChangeView.as_view(), name='password_change'),
    path('password-change/done/', views.PasswordChangeDoneView.as_view(), name='password_change_done'),
]

