"""
认证应用服务
"""
from .models import LoginAttempt, UserSession

def get_client_ip(request):
    """
    获取客户端IP地址
    """
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip

def get_user_agent(request):
    """
    获取用户代理
    """
    return request.META.get('HTTP_USER_AGENT', '')[:255]

def create_login_attempt(username, ip_address, user_agent, success, user=None):
    """
    创建登录尝试记录
    """
    return LoginAttempt.objects.create(
        username=username,
        ip_address=ip_address,
        user_agent=user_agent,
        success=success,
        user=user
    )

def create_user_session(user, session_key, ip_address, user_agent):
    """
    创建用户会话记录
    """
    return UserSession.objects.create(
        user=user,
        session_key=session_key,
        ip_address=ip_address,
        user_agent=user_agent
    )

def get_active_sessions(user):
    """
    获取用户活跃会话
    """
    return UserSession.objects.filter(user=user, is_active=True)

def terminate_all_sessions(user, current_session_key=None):
    """
    终止用户所有会话（可选保留当前会话）
    """
    sessions = UserSession.objects.filter(user=user, is_active=True)
    if current_session_key:
        sessions = sessions.exclude(session_key=current_session_key)
    return sessions.update(is_active=False)

