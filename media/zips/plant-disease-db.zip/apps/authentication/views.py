"""
认证应用视图
"""
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_protect
from django.views.decorators.debug import sensitive_post_parameters
from django.views.generic import FormView, RedirectView, TemplateView
from django.urls import reverse_lazy
from django.utils import timezone
from django.http import HttpResponseRedirect
from django.conf import settings
from django.db.models import Q

from .forms import LoginForm, RegisterForm, PasswordResetForm, PasswordChangeForm
from .models import User, LoginAttempt, UserSession
from .services import get_client_ip, get_user_agent, create_login_attempt, create_user_session

class LoginView(FormView):
    """
    用户登录视图
    """
    template_name = 'authentication/login.html'
    form_class = LoginForm
    success_url = reverse_lazy('dashboard:index')
    
    @method_decorator(sensitive_post_parameters('password'))
    @method_decorator(csrf_protect)
    def dispatch(self, request, *args, **kwargs):
        # 已登录用户重定向到首页
        if request.user.is_authenticated:
            return HttpResponseRedirect(self.get_success_url())
        return super().dispatch(request, *args, **kwargs)
    
    def form_valid(self, form):
        username = form.cleaned_data.get('username')
        password = form.cleaned_data.get('password')
        remember_me = form.cleaned_data.get('remember_me', False)
        
        user = authenticate(username=username, password=password)
        
        # 记录登录尝试
        ip_address = get_client_ip(self.request)
        user_agent = get_user_agent(self.request)
        
        if user is not None:
            login(self.request, user)
            
            # 设置会话过期时间
            if not remember_me:
                self.request.session.set_expiry(0)
            else:
                self.request.session.set_expiry(settings.SESSION_COOKIE_AGE)
            
            # 记录成功登录
            create_login_attempt(username, ip_address, user_agent, True, user)
            
            # 创建用户会话记录
            create_user_session(user, self.request.session.session_key, ip_address, user_agent)
            
            # 更新用户最后活动时间
            user.update_last_activity()
            
            messages.success(self.request, f'欢迎回来，{user.username}！')
            return super().form_valid(form)
        else:
            # 记录失败登录
            create_login_attempt(username, ip_address, user_agent, False)
            messages.error(self.request, '用户名或密码错误')
            return self.form_invalid(form)

class RegisterView(FormView):
    """
    用户注册视图
    """
    template_name = 'authentication/register.html'
    form_class = RegisterForm
    success_url = reverse_lazy('authentication:login')
    
    @method_decorator(sensitive_post_parameters('password1', 'password2'))
    @method_decorator(csrf_protect)
    def dispatch(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            return HttpResponseRedirect(reverse_lazy('dashboard:index'))
        return super().dispatch(request, *args, **kwargs)
    
    def form_valid(self, form):
        user = form.save(commit=False)
        user.set_password(form.cleaned_data.get('password1'))
        user.save()
        messages.success(self.request, '注册成功，请登录')
        return super().form_valid(form)

class LogoutView(RedirectView):
    """
    用户登出视图
    """
    url = reverse_lazy('authentication:login')
    
    def get(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            # 更新用户会话记录
            UserSession.objects.filter(
                user=request.user,
                session_key=request.session.session_key
            ).update(is_active=False)
            
            logout(request)
            messages.info(request, '您已成功退出登录')
        return super().get(request, *args, **kwargs)

class PasswordResetView(FormView):
    """
    密码重置视图
    """
    template_name = 'authentication/password_reset.html'
    form_class = PasswordResetForm
    success_url = reverse_lazy('authentication:password_reset_done')
    
    @method_decorator(csrf_protect)
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)
    
    def form_valid(self, form):
        # 发送密码重置邮件
        form.save(
            request=self.request,
            use_https=self.request.is_secure(),
            from_email=settings.DEFAULT_FROM_EMAIL,
        )
        return super().form_valid(form)

class PasswordResetDoneView(TemplateView):
    """
    密码重置完成视图
    """
    template_name = 'authentication/password_reset_done.html'

@method_decorator(login_required, name='dispatch')
class PasswordChangeView(FormView):
    """
    密码修改视图
    """
    template_name = 'authentication/password_change.html'
    form_class = PasswordChangeForm
    success_url = reverse_lazy('authentication:password_change_done')
    
    @method_decorator(sensitive_post_parameters('old_password', 'new_password1', 'new_password2'))
    @method_decorator(csrf_protect)
    def dispatch(self, request, *args, **kwargs):
        return super().dispatch(request, *args, **kwargs)
    
    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        return kwargs
    
    def form_valid(self, form):
        form.save()
        messages.success(self.request, '密码修改成功')
        return super().form_valid(form)

class PasswordChangeDoneView(TemplateView):
    """
    密码修改完成视图
    """
    template_name = 'authentication/password_change_done.html'

