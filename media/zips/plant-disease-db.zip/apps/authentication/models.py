"""
认证应用模型
"""
from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils.translation import gettext_lazy as _
from django.utils import timezone
import uuid

class User(AbstractUser):
    """
    自定义用户模型
    """
    USER_TYPE_CHOICES = (
        ('admin', _('超级管理员')),
        ('researcher', _('研究人员')),
        ('regular', _('普通用户')),
        ('guest', _('访客')),
    )
    
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user_type = models.CharField(_('用户类型'), max_length=20, choices=USER_TYPE_CHOICES, default='regular')
    phone = models.CharField(_('手机号'), max_length=20, blank=True, null=True)
    avatar = models.ImageField(_('头像'), upload_to='avatars/', blank=True, null=True)
    bio = models.TextField(_('个人简介'), blank=True, null=True)
    organization = models.CharField(_('所属组织'), max_length=100, blank=True, null=True)
    position = models.CharField(_('职位'), max_length=100, blank=True, null=True)
    last_activity = models.DateTimeField(_('最后活动时间'), default=timezone.now)
    
    class Meta:
        verbose_name = _('用户')
        verbose_name_plural = _('用户')
        ordering = ['-date_joined']
    
    def __str__(self):
        return self.username
    
    def is_admin(self):
        """
        检查用户是否为管理员
        """
        return self.user_type == 'admin'
    
    def is_researcher(self):
        """
        检查用户是否为研究人员
        """
        return self.user_type == 'researcher'
    
    def update_last_activity(self):
        """
        更新最后活动时间
        """
        self.last_activity = timezone.now()
        self.save(update_fields=['last_activity'])

class LoginAttempt(models.Model):
    """
    登录尝试记录
    """
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True, related_name='login_attempts')
    ip_address = models.GenericIPAddressField(_('IP地址'))
    user_agent = models.CharField(_('用户代理'), max_length=255)
    timestamp = models.DateTimeField(_('时间戳'), auto_now_add=True)
    success = models.BooleanField(_('是否成功'), default=False)
    username = models.CharField(_('用户名'), max_length=150)
    
    class Meta:
        verbose_name = _('登录尝试')
        verbose_name_plural = _('登录尝试')
        ordering = ['-timestamp']
    
    def __str__(self):
        return f"{self.username} - {self.timestamp} - {'成功' if self.success else '失败'}"

class UserSession(models.Model):
    """
    用户会话记录
    """
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sessions')
    session_key = models.CharField(_('会话密钥'), max_length=40)
    ip_address = models.GenericIPAddressField(_('IP地址'))
    user_agent = models.CharField(_('用户代理'), max_length=255)
    created_at = models.DateTimeField(_('创建时间'), auto_now_add=True)
    last_activity = models.DateTimeField(_('最后活动时间'), auto_now=True)
    is_active = models.BooleanField(_('是否活跃'), default=True)
    
    class Meta:
        verbose_name = _('用户会话')
        verbose_name_plural = _('用户会话')
        ordering = ['-last_activity']
    
    def __str__(self):
        return f"{self.user.username} - {self.created_at}"

