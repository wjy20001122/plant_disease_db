"""
表格数据模型
"""
from django.db import models
from django.utils.translation import gettext_lazy as _
from .base import BaseData
import os

class TableData(BaseData):
    """
    表格数据模型
    """
    TABLE_TYPE_CHOICES = (
        ('experiment', _('实验数据')),
        ('survey', _('调查数据')),
        ('analysis', _('分析结果')),
        ('other', _('其他')),
    )
    
    file = models.FileField(_('文件'), upload_to='tables/%Y/%m/%d/')
    table_type = models.CharField(_('表格类型'), max_length=20, choices=TABLE_TYPE_CHOICES, default='experiment')
    source = models.CharField(_('数据来源'), max_length=255, blank=True, null=True)
    disease = models.ForeignKey('disease_data.Disease', on_delete=models.SET_NULL, blank=True, null=True, related_name='tables', verbose_name=_('病害'))
    file_size = models.PositiveIntegerField(_('文件大小(KB)'), blank=True, null=True)
    
    class Meta:
        verbose_name = _('表格数据')
        verbose_name_plural = _('表格数据')
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['crop_type']),
            models.Index(fields=['region']),
            models.Index(fields=['table_type']),
            models.Index(fields=['disease']),
        ]
    
    def save(self, *args, **kwargs):
        """
        重写保存方法，自动计算文件大小
        """
        if self.file and not self.file_size:
            self.file_size = self.file.size // 1024  # 转换为KB
        super().save(*args, **kwargs)
    
    @property
    def file_extension(self):
        """
        获取文件扩展名
        """
        return os.path.splitext(self.file.name)[1].lower() if self.file else ''
    
    @property
    def file_name(self):
        """
        获取文件名
        """
        return os.path.basename(self.file.name) if self.file else ''

