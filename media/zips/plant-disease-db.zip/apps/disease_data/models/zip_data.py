"""
ZIP文件数据模型
"""
from django.db import models
from django.utils.translation import gettext_lazy as _
from .base import BaseData
import os

class ZipData(BaseData):
    """
    ZIP文件数据模型
    """
    ZIP_TYPE_CHOICES = (
        ('images', _('图片集')),
        ('tables', _('表格集')),
        ('mixed', _('混合数据')),
        ('other', _('其他')),
    )
    
    file = models.FileField(_('文件'), upload_to='zips/%Y/%m/%d/')
    zip_type = models.CharField(_('ZIP类型'), max_length=20, choices=ZIP_TYPE_CHOICES, default='mixed')
    file_count = models.PositiveIntegerField(_('文件数量'), blank=True, null=True)
    file_size = models.PositiveIntegerField(_('文件大小(KB)'), blank=True, null=True)
    disease = models.ForeignKey('disease_data.Disease', on_delete=models.SET_NULL, blank=True, null=True, related_name='zips', verbose_name=_('病害'))
    
    class Meta:
        verbose_name = _('ZIP文件数据')
        verbose_name_plural = _('ZIP文件数据')
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['crop_type']),
            models.Index(fields=['region']),
            models.Index(fields=['zip_type']),
            models.Index(fields=['disease']),
        ]
    
    def save(self, *args, **kwargs):
        """
        重写保存方法，自动计算文件大小
        """
        if self.file and not self.file_size:
            self.file_size = self.file.size // 1024  # 转换为KB
        super().save(*args, **kwargs)
    
    @property
    def file_name(self):
        """
        获取文件名
        """
        return os.path.basename(self.file.name) if self.file else ''

