"""
地区模型
"""
from django.db import models
from django.utils.translation import gettext_lazy as _
from .base import BaseModel

class Region(BaseModel):
    """
    地区模型
    """
    name = models.CharField(_('地区名称'), max_length=100)
    code = models.CharField(_('地区代码'), max_length=50, blank=True, null=True)
    parent = models.ForeignKey('self', on_delete=models.CASCADE, blank=True, null=True, related_name='children', verbose_name=_('上级地区'))
    level = models.PositiveSmallIntegerField(_('级别'), default=0)  # 0: 国家, 1: 省, 2: 市, 3: 县
    
    class Meta:
        verbose_name = _('地区')
        verbose_name_plural = _('地区')
        ordering = ['level', 'name']
        unique_together = ('name', 'parent')
    
    def __str__(self):
        return self.name
    
    @property
    def full_name(self):
        """
        获取完整地区名称
        """
        if self.parent:
            return f"{self.parent.full_name} - {self.name}"
        return self.name

