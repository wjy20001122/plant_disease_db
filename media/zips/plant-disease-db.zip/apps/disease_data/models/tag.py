"""
标签模型
"""
from django.db import models
from django.utils.translation import gettext_lazy as _
from django.utils.text import slugify
from .base import BaseModel

class Tag(BaseModel):
    """
    标签模型
    """
    name = models.CharField(_('标签名称'), max_length=50)
    slug = models.SlugField(_('别名'), max_length=50, unique=True)
    
    class Meta:
        verbose_name = _('标签')
        verbose_name_plural = _('标签')
        ordering = ['name']
    
    def __str__(self):
        return self.name
    
    def save(self, *args, **kwargs):
        """
        重写保存方法，自动生成slug
        """
        if not self.slug:
            self.slug = slugify(self.name)
            
            # 确保slug唯一
            original_slug = self.slug
            counter = 1
            while Tag.objects.filter(slug=self.slug).exists():
                self.slug = f"{original_slug}-{counter}"
                counter += 1
                
        super().save(*args, **kwargs)

