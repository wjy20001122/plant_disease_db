"""
图片数据模型
"""
from django.db import models
from django.utils.translation import gettext_lazy as _
from .base import BaseData
from PIL import Image as PILImage
from io import BytesIO
from django.core.files.base import ContentFile
import os

class ImageData(BaseData):
    """
    图片数据模型
    """
    IMAGE_TYPE_CHOICES = (
        ('field', _('田间照片')),
        ('microscope', _('显微照片')),
        ('symptom', _('症状照片')),
        ('other', _('其他')),
    )
    
    image = models.ImageField(_('图片'), upload_to='images/%Y/%m/%d/')
    thumbnail = models.ImageField(_('缩略图'), upload_to='thumbnails/%Y/%m/%d/', blank=True, null=True)
    image_type = models.CharField(_('图片类型'), max_length=20, choices=IMAGE_TYPE_CHOICES, default='field')
    width = models.PositiveIntegerField(_('宽度'), blank=True, null=True)
    height = models.PositiveIntegerField(_('高度'), blank=True, null=True)
    disease = models.ForeignKey('disease_data.Disease', on_delete=models.SET_NULL, blank=True, null=True, related_name='images', verbose_name=_('病害'))
    
    class Meta:
        verbose_name = _('图片数据')
        verbose_name_plural = _('图片数据')
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['crop_type']),
            models.Index(fields=['region']),
            models.Index(fields=['image_type']),
            models.Index(fields=['disease']),
        ]
    
    def save(self, *args, **kwargs):
        """
        重写保存方法，自动生成缩略图并获取图片尺寸
        """
        if not self.id and not self.thumbnail:
            self.create_thumbnail()
        
        if not self.width or not self.height:
            self.update_dimensions()
            
        super().save(*args, **kwargs)
    
    def create_thumbnail(self):
        """
        创建缩略图
        """
        if not self.image:
            return
            
        # 打开原始图片
        img = PILImage.open(self.image)
        
        # 保持宽高比例缩放
        img.thumbnail((300, 300), PILImage.LANCZOS)
        
        # 保存缩略图
        thumb_io = BytesIO()
        img_format = 'JPEG' if self.image.name.lower().endswith('.jpg') or self.image.name.lower().endswith('.jpeg') else 'PNG'
        img.save(thumb_io, format=img_format, quality=85)
        
        # 生成缩略图文件名
        file_name = os.path.basename(self.image.name)
        name, ext = os.path.splitext(file_name)
        thumb_name = f"{name}_thumb{ext}"
        
        # 保存到模型字段
        self.thumbnail.save(thumb_name, ContentFile(thumb_io.getvalue()), save=False)
        thumb_io.close()
    
    def update_dimensions(self):
        """
        更新图片尺寸
        """
        if not self.image:
            return
            
        img = PILImage.open(self.image)
        self.width, self.height = img.size

