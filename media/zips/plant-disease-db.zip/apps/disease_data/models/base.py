"""
疾病数据基础模型
"""
from django.db import models
from django.utils.translation import gettext_lazy as _
from django.conf import settings
import uuid

class BaseModel(models.Model):
    """
    基础模型，包含所有模型共有的字段
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    created_at = models.DateTimeField(_('创建时间'), auto_now_add=True)
    updated_at = models.DateTimeField(_('更新时间'), auto_now=True)
    
    class Meta:
        abstract = True

class BaseData(BaseModel):
    """
    基础数据模型，包含所有数据类型共有的字段
    """
    CROP_CHOICES = (
        ('corn', _('玉米')),
        ('wheat', _('小麦')),
        ('rice', _('水稻')),
        ('soybean', _('大豆')),
        ('other', _('其他')),
    )
    
    STATUS_CHOICES = (
        ('draft', _('草稿')),
        ('published', _('已发布')),
        ('archived', _('已归档')),
    )
    
    name = models.CharField(_('名称'), max_length=255)
    description = models.TextField(_('描述'), blank=True, null=True)
    crop_type = models.CharField(_('作物类型'), max_length=20, choices=CROP_CHOICES)
    region = models.CharField(_('地区'), max_length=100)
    uploader = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='%(class)s_uploads',
        verbose_name=_('上传者')
    )
    status = models.CharField(_('状态'), max_length=20, choices=STATUS_CHOICES, default='published')
    tags = models.ManyToManyField('disease_data.Tag', blank=True, related_name='%(class)s_items', verbose_name=_('标签'))
    is_public = models.BooleanField(_('是否公开'), default=True)
    view_count = models.PositiveIntegerField(_('查看次数'), default=0)
    download_count = models.PositiveIntegerField(_('下载次数'), default=0)
    
    class Meta:
        abstract = True
        ordering = ['-created_at']
    
    def __str__(self):
        return self.name
    
    def increment_view_count(self):
        """
        增加查看次数
        """
        self.view_count += 1
        self.save(update_fields=['view_count'])
    
    def increment_download_count(self):
        """
        增加下载次数
        """
        self.download_count += 1
        self.save(update_fields=['download_count'])

