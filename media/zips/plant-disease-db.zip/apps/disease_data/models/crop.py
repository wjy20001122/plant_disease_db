"""
作物模型
"""
from django.db import models
from django.utils.translation import gettext_lazy as _
from django.utils.text import slugify
from .base import BaseModel

class Crop(BaseModel):
    """
    作物模型
    """
    name = models.CharField(_('作物名称'), max_length=100)
    scientific_name = models.CharField(_('学名'), max_length=255, blank=True, null=True)
    slug = models.SlugField(_('别名'), max_length=100, unique=True)
    description = models.TextField(_('描述'), blank=True, null=True)
    
    class Meta:
        verbose_name = _('作物')
        verbose_name_plural = _('作物')
        ordering = ['name']
    
    def __str__(self):
        return self.name
    
    def save(self, *args, **kwargs):
        """
        重写保存方法，自动生成slug
        """
        if not self.slug:
            self.slug = slugify(self.name)
            
            # 确保slug唯一
            original_slug = self.slug
            counter = 1
            while Crop.objects.filter(slug=self.slug).exists():
                self.slug = f"{original_slug}-{counter}"
                counter += 1
                
        super().save(*args, **kwargs)
    
    @property
    def disease_count(self):
        """
        获取病害数量
        """
        return self.diseases.count()

