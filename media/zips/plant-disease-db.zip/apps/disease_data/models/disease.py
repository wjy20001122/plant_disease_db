"""
病害模型
"""
from django.db import models
from django.utils.translation import gettext_lazy as _
from django.utils.text import slugify
from .base import BaseModel
import uuid

class Disease(BaseModel):
    """
    病害模型
    """
    SEVERITY_CHOICES = (
        ('low', _('轻度')),
        ('medium', _('中度')),
        ('high', _('重度')),
        ('critical', _('危急')),
    )
    
    name = models.CharField(_('病害名称'), max_length=255)
    scientific_name = models.CharField(_('学名'), max_length=255, blank=True, null=True)
    slug = models.SlugField(_('别名'), max_length=255, unique=True)
    description = models.TextField(_('描述'), blank=True, null=True)
    symptoms = models.TextField(_('症状'), blank=True, null=True)
    causes = models.TextField(_('病因'), blank=True, null=True)
    treatment = models.TextField(_('防治方法'), blank=True, null=True)
    severity = models.CharField(_('严重程度'), max_length=20, choices=SEVERITY_CHOICES, default='medium')
    crops = models.ManyToManyField('disease_data.Crop', related_name='diseases', verbose_name=_('影响作物'))
    
    class Meta:
        verbose_name = _('病害')
        verbose_name_plural = _('病害')
        ordering = ['name']
    
    def __str__(self):
        return self.name
    
    def save(self, *args, **kwargs):
        """
        重写保存方法，自动生成slug
        """
        if not self.slug:
            self.slug = slugify(self.name)
            
            # 确保slug唯一
            original_slug = self.slug
            counter = 1
            while Disease.objects.filter(slug=self.slug).exists():
                self.slug = f"{original_slug}-{counter}"
                counter += 1
                
        super().save(*args, **kwargs)
    
    @property
    def image_count(self):
        """
        获取图片数量
        """
        return self.images.count()
    
    @property
    def table_count(self):
        """
        获取表格数量
        """
        return self.tables.count()
    
    @property
    def zip_count(self):
        """
        获取ZIP文件数量
        """
        return self.zips.count()

