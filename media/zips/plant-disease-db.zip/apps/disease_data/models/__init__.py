"""
疾病数据模型初始化
"""
from .base import BaseModel, BaseData
from .image_data import ImageData
from .table_data import TableData
from .zip_data import ZipData
from .disease import Disease
from .crop import Crop
from .region import Region
from .tag import Tag

__all__ = [
    'BaseModel',
    'BaseData',
    'ImageData',
    'TableData',
    'ZipData',
    'Disease',
    'Crop',
    'Region',
    'Tag',
]

