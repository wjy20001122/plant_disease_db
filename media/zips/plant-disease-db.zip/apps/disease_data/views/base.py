"""
基础视图
"""
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.urls import reverse_lazy
from django.contrib import messages
from django.shortcuts import redirect
from django.db.models import Q

class BaseListView(LoginRequiredMixin, ListView):
    """
    基础列表视图
    """
    paginate_by = 20
    context_object_name = 'objects'
    
    def get_queryset(self):
        """
        获取查询集，根据用户权限过滤
        """
        queryset = super().get_queryset()
        
        # 如果不是管理员，只显示公开数据和自己上传的数据
        if not self.request.user.is_admin():
            queryset = queryset.filter(
                Q(is_public=True) | Q(uploader=self.request.user)
            )
        
        return queryset
    
    def get_context_data(self, **kwargs):
        """
        获取上下文数据
        """
        context = super().get_context_data(**kwargs)
        context['title'] = self.title if hasattr(self, 'title') else '数据列表'
        return context

class BaseDetailView(LoginRequiredMixin, UserPassesTestMixin, DetailView):
    """
    基础详情视图
    """
    context_object_name = 'object'
    
    def test_func(self):
        """
        检查用户是否有权限查看
        """
        obj = self.get_object()
        # 管理员可以查看所有数据
        if self.request.user.is_admin():
            return True
        # 用户可以查看公开数据和自己上传的数据
        return obj.is_public or obj.uploader == self.request.user
    
    def get_context_data(self, **kwargs):
        """
        获取上下文数据
        """
        context = super().get_context_data(**kwargs)
        context['title'] = self.title if hasattr(self, 'title') else '数据详情'
        
        # 增加查看次数
        obj = self.get_object()
        obj.increment_view_count()
        
        return context

class BaseCreateView(LoginRequiredMixin, CreateView):
    """
    基础创建视图
    """
    def form_valid(self, form):
        """
        表单验证成功
        """
        form.instance.uploader = self.request.user
        messages.success(self.request, '数据创建成功')
        return super().form_valid(form)
    
    def get_context_data(self, **kwargs):
        """
        获取上下文数据
        """
        context = super().get_context_data(**kwargs)
        context['title'] = self.title if hasattr(self, 'title') else '创建数据'
        return context

class BaseUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    """
    基础更新视图
    """
    def test_func(self):
        """
        检查用户是否有权限更新
        """
        obj = self.get_object()
        # 管理员可以更新所有数据
        if self.request.user.is_admin():
            return True
        # 用户只能更新自己上传的数据
        return obj.uploader == self.request.user
    
    def form_valid(self, form):
        """
        表单验证成功
        """
        messages.success(self.request, '数据更新成功')
        return super().form_valid(form)
    
    def get_context_data(self, **kwargs):
        """
        获取上下文数据
        """
        context = super().get_context_data(**kwargs)
        context['title'] = self.title if hasattr(self, 'title') else '更新数据'
        return context

class BaseDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    """
    基础删除视图
    """
    def test_func(self):
        """
        检查用户是否有权限删除
        """
        obj = self.get_object()
        # 管理员可以删除所有数据
        if self.request.user.is_admin():
            return True
        # 用户只能删除自己上传的数据
        return obj.uploader == self.request.user
    
    def delete(self, request, *args, **kwargs):
        """
        删除对象
        """
        messages.success(request, '数据删除成功')
        return super().delete(request, *args, **kwargs)
    
    def get_context_data(self, **kwargs):
        """
        获取上下文数据
        """
        context = super().get_context_data(**kwargs)
        context['title'] = self.title if hasattr(self, 'title') else '删除数据'
        return context

