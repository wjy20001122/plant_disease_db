"""
ZIP文件数据视图
"""
from django.urls import reverse_lazy
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from django.contrib.auth.decorators import login_required
import os

from .base import BaseListView, BaseDetailView, BaseCreateView, BaseUpdateView, BaseDeleteView
from ..models import ZipData, Disease, Crop
from ..forms import ZipDataForm

class ZipListView(BaseListView):
    """
    ZIP文件列表视图
    """
    model = ZipData
    template_name = 'disease_data/zip_list.html'
    context_object_name = 'zips'
    title = 'ZIP文件列表'
    
    def get_queryset(self):
        """
        获取查询集，支持过滤
        """
        queryset = super().get_queryset()
        
        # 过滤条件
        crop_type = self.request.GET.get('crop_type')
        region = self.request.GET.get('region')
        disease = self.request.GET.get('disease')
        zip_type = self.request.GET.get('zip_type')
        search = self.request.GET.get('search')
        
        if crop_type:
            queryset = queryset.filter(crop_type=crop_type)
        if region:
            queryset = queryset.filter(region__icontains=region)
        if disease:
            queryset = queryset.filter(disease_id=disease)
        if zip_type:
            queryset = queryset.filter(zip_type=zip_type)
        if search:
            queryset = queryset.filter(name__icontains=search)
        
        return queryset
    
    def get_context_data(self, **kwargs):
        """
        获取上下文数据
        """
        context = super().get_context_data(**kwargs)
        context['crop_types'] = dict(ZipData.CROP_CHOICES)
        context['zip_types'] = dict(ZipData.ZIP_TYPE_CHOICES)
        context['diseases'] = Disease.objects.all()
        
        # 当前过滤条件
        context['current_filters'] = {
            'crop_type': self.request.GET.get('crop_type', ''),
            'region': self.request.GET.get('region', ''),
            'disease': self.request.GET.get('disease', ''),
            'zip_type': self.request.GET.get('zip_type', ''),
            'search': self.request.GET.get('search', ''),
        }
        
        return context

class ZipDetailView(BaseDetailView):
    """
    ZIP文件详情视图
    """
    model = ZipData
    template_name = 'disease_data/zip_detail.html'
    context_object_name = 'zip'
    title = 'ZIP文件详情'

class ZipCreateView(BaseCreateView):
    """
    ZIP文件创建视图
    """
    model = ZipData
    form_class = ZipDataForm
    template_name = 'disease_data/zip_form.html'
    success_url = reverse_lazy('disease_data:zip_list')
    title = '上传ZIP文件'
    
    def get_context_data(self, **kwargs):
        """
        获取上下文数据
        """
        context = super().get_context_data(**kwargs)
        context['diseases'] = Disease.objects.all()
        context['crops'] = Crop.objects.all()
        return context

class ZipUpdateView(BaseUpdateView):
    """
    ZIP文件更新视图
    """
    model = ZipData
    form_class = ZipDataForm
    template_name = 'disease_data/zip_form.html'
    success_url = reverse_lazy('disease_data:zip_list')
    title = '编辑ZIP文件'
    
    def get_context_data(self, **kwargs):
        """
        获取上下文数据
        """
        context = super().get_context_data(**kwargs)
        context['diseases'] = Disease.objects.all()
        context['crops'] = Crop.objects.all()
        return context

class ZipDeleteView(BaseDeleteView):
    """
    ZIP文件删除视图
    """
    model = ZipData
    template_name = 'disease_data/zip_confirm_delete.html'
    success_url = reverse_lazy('disease_data:zip_list')
    title = '删除ZIP文件'

@login_required
def download_zip(request, pk):
    """
    下载ZIP文件
    """
    zip_data = get_object_or_404(ZipData, pk=pk)
    
    # 检查权限
    if not zip_data.is_public and not request.user.is_admin() and request.user != zip_data.uploader:
        return HttpResponse('无权限下载', status=403)
    
    # 增加下载次数
    zip_data.increment_download_count()
    
    # 读取文件
    file_path = zip_data.file.path
    with open(file_path, 'rb') as f:
        response = HttpResponse(f.read(), content_type='application/zip')
        response['Content-Disposition'] = f'attachment; filename="{os.path.basename(file_path)}"'
        return response

