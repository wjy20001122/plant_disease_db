"""
表格数据视图
"""
from django.urls import reverse_lazy
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from django.contrib.auth.decorators import login_required
import os

from .base import BaseListView, BaseDetailView, BaseCreateView, BaseUpdateView, BaseDeleteView
from ..models import TableData, Disease, Crop
from ..forms import TableDataForm

class TableListView(BaseListView):
    """
    表格列表视图
    """
    model = TableData
    template_name = 'disease_data/table_list.html'
    context_object_name = 'tables'
    title = '表格数据列表'
    
    def get_queryset(self):
        """
        获取查询集，支持过滤
        """
        queryset = super().get_queryset()
        
        # 过滤条件
        crop_type = self.request.GET.get('crop_type')
        region = self.request.GET.get('region')
        disease = self.request.GET.get('disease')
        table_type = self.request.GET.get('table_type')
        search = self.request.GET.get('search')
        
        if crop_type:
            queryset = queryset.filter(crop_type=crop_type)
        if region:
            queryset = queryset.filter(region__icontains=region)
        if disease:
            queryset = queryset.filter(disease_id=disease)
        if table_type:
            queryset = queryset.filter(table_type=table_type)
        if search:
            queryset = queryset.filter(name__icontains=search)
        
        return queryset
    
    def get_context_data(self, **kwargs):
        """
        获取上下文数据
        """
        context = super().get_context_data(**kwargs)
        context['crop_types'] = dict(TableData.CROP_CHOICES)
        context['table_types'] = dict(TableData.TABLE_TYPE_CHOICES)
        context['diseases'] = Disease.objects.all()
        
        # 当前过滤条件
        context['current_filters'] = {
            'crop_type': self.request.GET.get('crop_type', ''),
            'region': self.request.GET.get('region', ''),
            'disease': self.request.GET.get('disease', ''),
            'table_type': self.request.GET.get('table_type', ''),
            'search': self.request.GET.get('search', ''),
        }
        
        return context

class TableDetailView(BaseDetailView):
    """
    表格详情视图
    """
    model = TableData
    template_name = 'disease_data/table_detail.html'
    context_object_name = 'table'
    title = '表格详情'

class TableCreateView(BaseCreateView):
    """
    表格创建视图
    """
    model = TableData
    form_class = TableDataForm
    template_name = 'disease_data/table_form.html'
    success_url = reverse_lazy('disease_data:table_list')
    title = '上传表格'
    
    def get_context_data(self, **kwargs):
        """
        获取上下文数据
        """
        context = super().get_context_data(**kwargs)
        context['diseases'] = Disease.objects.all()
        context['crops'] = Crop.objects.all()
        return context

class TableUpdateView(BaseUpdateView):
    """
    表格更新视图
    """
    model = TableData
    form_class = TableDataForm
    template_name = 'disease_data/table_form.html'
    success_url = reverse_lazy('disease_data:table_list')
    title = '编辑表格'
    
    def get_context_data(self, **kwargs):
        """
        获取上下文数据
        """
        context = super().get_context_data(**kwargs)
        context['diseases'] = Disease.objects.all()
        context['crops'] = Crop.objects.all()
        return context

class TableDeleteView(BaseDeleteView):
    """
    表格删除视图
    """
    model = TableData
    template_name = 'disease_data/table_confirm_delete.html'
    success_url = reverse_lazy('disease_data:table_list')
    title = '删除表格'

@login_required
def download_table(request, pk):
    """
    下载表格
    """
    table = get_object_or_404(TableData, pk=pk)
    
    # 检查权限
    if not table.is_public and not request.user.is_admin() and request.user != table.uploader:
        return HttpResponse('无权限下载', status=403)
    
    # 增加下载次数
    table.increment_download_count()
    
    # 读取文件
    file_path = table.file.path
    with open(file_path, 'rb') as f:
        response = HttpResponse(f.read(), content_type='application/octet-stream')
        response['Content-Disposition'] = f'attachment; filename="{os.path.basename(file_path)}"'
        return response

