from django import forms
from .models import ImageData, TableData, ZipData

class ImageDataForm(forms.ModelForm):
    class Meta:
        model = ImageData
        fields = ('name', 'crop_type', 'region', 'description', 'image')
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'crop_type': forms.Select(attrs={'class': 'form-control'}),
            'region': forms.TextInput(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'image': forms.FileInput(attrs={'class': 'form-control'}),
        }

class TableDataForm(forms.ModelForm):
    class Meta:
        model = TableData
        fields = ('name', 'crop_type', 'region', 'description', 'source', 'file')
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'crop_type': forms.Select(attrs={'class': 'form-control'}),
            'region': forms.TextInput(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'source': forms.TextInput(attrs={'class': 'form-control'}),
            'file': forms.FileInput(attrs={'class': 'form-control'}),
        }

class ZipDataForm(forms.ModelForm):
    class Meta:
        model = ZipData
        fields = ('name', 'crop_type', 'region', 'description', 'file')
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control'}),
            'crop_type': forms.Select(attrs={'class': 'form-control'}),
            'region': forms.TextInput(attrs={'class': 'form-control'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'file': forms.FileInput(attrs={'class': 'form-control'}),
        }

