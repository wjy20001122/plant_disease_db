from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from .models import ImageData, TableData, ZipData
from .forms import ImageDataForm, TableDataForm, ZipDataForm
from django.contrib import messages
import os

@login_required
def upload_image(request):
    if request.method == 'POST':
        form = ImageDataForm(request.POST, request.FILES)
        if form.is_valid():
            image_data = form.save(commit=False)
            image_data.uploader = request.user
            image_data.save()
            messages.success(request, '图片上传成功')
            return redirect('dashboard:index')
    else:
        form = ImageDataForm()
    return render(request, 'data_management/upload_image.html', {'form': form})

@login_required
def upload_table(request):
    if request.method == 'POST':
        form = TableDataForm(request.POST, request.FILES)
        if form.is_valid():
            table_data = form.save(commit=False)
            table_data.uploader = request.user
            table_data.save()
            messages.success(request, '表格上传成功')
            return redirect('dashboard:index')
    else:
        form = TableDataForm()
    return render(request, 'data_management/upload_table.html', {'form': form})

@login_required
def upload_zip(request):
    if request.method == 'POST':
        form = ZipDataForm(request.POST, request.FILES)
        if form.is_valid():
            zip_data = form.save(commit=False)
            zip_data.uploader = request.user
            zip_data.save()
            messages.success(request, 'ZIP文件上传成功')
            return redirect('dashboard:index')
    else:
        form = ZipDataForm()
    return render(request, 'data_management/upload_zip.html', {'form': form})

@login_required
def delete_data(request, data_type, data_id):
    if data_type == 'image':
        data = get_object_or_404(ImageData, id=data_id)
    elif data_type == 'table':
        data = get_object_or_404(TableData, id=data_id)
    elif data_type == 'zip':
        data = get_object_or_404(ZipData, id=data_id)
    else:
        messages.error(request, '无效的数据类型')
        return redirect('dashboard:index')
    
    # 检查权限
    if request.user.is_admin() or data.uploader == request.user:
        data.delete()
        messages.success(request, '数据删除成功')
    else:
        messages.error(request, '您没有权限删除此数据')
    
    return redirect('dashboard:index')

@login_required
def download_data(request, data_type, data_id):
    if data_type == 'image':
        data = get_object_or_404(ImageData, id=data_id)
        file_path = data.image.path
    elif data_type == 'table':
        data = get_object_or_404(TableData, id=data_id)
        file_path = data.file.path
    elif data_type == 'zip':
        data = get_object_or_404(ZipData, id=data_id)
        file_path = data.file.path
    else:
        messages.error(request, '无效的数据类型')
        return redirect('dashboard:index')
    
    if os.path.exists(file_path):
        with open(file_path, 'rb') as fh:
            response = HttpResponse(fh.read())
            response['Content-Disposition'] = f'attachment; filename={os.path.basename(file_path)}'
            return response
    
    messages.error(request, '文件不存在')
    return redirect('dashboard:index')

