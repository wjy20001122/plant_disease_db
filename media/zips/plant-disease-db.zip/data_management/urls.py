from django.urls import path
from . import views

app_name = 'data_management'

urlpatterns = [
    path('upload/image/', views.upload_image, name='upload_image'),
    path('upload/table/', views.upload_table, name='upload_table'),
    path('upload/zip/', views.upload_zip, name='upload_zip'),
    path('delete/<str:data_type>/<int:data_id>/', views.delete_data, name='delete_data'),
    path('download/<str:data_type>/<int:data_id>/', views.download_data, name='download_data'),
]

