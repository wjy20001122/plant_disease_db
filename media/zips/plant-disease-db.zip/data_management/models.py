from django.db import models
from authentication.models import User

class BaseData(models.Model):
    CROP_CHOICES = (
        ('corn', '玉米'),
        ('wheat', '小麦'),
    )
    
    name = models.CharField(max_length=100, verbose_name='名称')
    upload_time = models.DateTimeField(auto_now_add=True, verbose_name='上传时间')
    uploader = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='上传人')
    crop_type = models.CharField(max_length=10, choices=CROP_CHOICES, verbose_name='作物类型')
    region = models.CharField(max_length=100, verbose_name='地区')
    description = models.TextField(blank=True, null=True, verbose_name='描述')
    
    class Meta:
        abstract = True

class ImageData(BaseData):
    image = models.ImageField(upload_to='images/', verbose_name='图片')
    
    class Meta:
        verbose_name = '图片数据'
        verbose_name_plural = '图片数据'

class TableData(BaseData):
    file = models.FileField(upload_to='documents/', verbose_name='表格文件')
    source = models.CharField(max_length=100, verbose_name='数据来源')
    
    class Meta:
        verbose_name = '表格数据'
        verbose_name_plural = '表格数据'

class ZipData(BaseData):
    file = models.FileField(upload_to='zip_files/', verbose_name='ZIP文件')
    
    class Meta:
        verbose_name = 'ZIP文件数据'
        verbose_name_plural = 'ZIP文件数据'

