/**
 * 植物病害数据库系统主要JavaScript文件
 */

// 页面加载完成后执行
document.addEventListener("DOMContentLoaded", () => {
  // 初始化工具提示
  initTooltips()

  // 初始化表单验证
  initFormValidation()

  // 初始化图片预览
  initImagePreview()

  // 初始化数据表格
  initDataTables()

  // 初始化侧边栏
  initSidebar()

  // 初始化加载动画
  initLoadingSpinner()
})

/**
 * 初始化Bootstrap工具提示
 */
function initTooltips() {
  const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
  tooltipTriggerList.map((tooltipTriggerEl) => new bootstrap.Tooltip(tooltipTriggerEl))
}

/**
 * 初始化表单验证
 */
function initFormValidation() {
  // 获取所有需要验证的表单
  const forms = document.querySelectorAll(".needs-validation")

  // 遍历表单并添加验证
  Array.from(forms).forEach((form) => {
    form.addEventListener(
      "submit",
      (event) => {
        if (!form.checkValidity()) {
          event.preventDefault()
          event.stopPropagation()
        }

        form.classList.add("was-validated")
      },
      false,
    )
  })
}

/**
 * 初始化图片预览功能
 */
function initImagePreview() {
  // 获取所有图片上传输入框
  const imageInputs = document.querySelectorAll('input[type="file"][accept*="image"]')

  // 为每个输入框添加预览功能
  imageInputs.forEach((input) => {
    input.addEventListener("change", function () {
      const file = this.files[0]
      if (file) {
        const reader = new FileReader()
        const previewId = this.dataset.preview

        if (previewId) {
          const previewElement = document.getElementById(previewId)

          reader.onload = (e) => {
            previewElement.src = e.target.result
            previewElement.style.display = "block"
          }

          reader.readAsDataURL(file)
        }
      }
    })
  })
}

/**
 * 初始化DataTables
 */
function initDataTables() {
  // 获取所有需要初始化为DataTable的表格
  const tables = document.querySelectorAll(".datatable")

  // 初始化每个表格
  tables.forEach((table) => {
    new DataTable(table, {
      language: {
        url: "//cdn.datatables.net/plug-ins/1.13.6/i18n/zh.json",
      },
      responsive: true,
      pageLength: 10,
      lengthMenu: [5, 10, 25, 50, 100],
      dom: "Bfrtip",
      buttons: ["copy", "csv", "excel", "pdf", "print"],
    })
  })
}

/**
 * 初始化侧边栏
 */
function initSidebar() {
  // 获取侧边栏切换按钮
  const sidebarToggle = document.getElementById("sidebarToggle")

  if (sidebarToggle) {
    // 切换侧边栏
    sidebarToggle.addEventListener("click", (e) => {
      e.preventDefault()
      document.body.classList.toggle("sidebar-toggled")
      document.querySelector(".sidebar").classList.toggle("toggled")

      // 保存状态到本地存储
      const isToggled = document.querySelector(".sidebar").classList.contains("toggled")
      localStorage.setItem("sidebar-toggled", isToggled)
    })

    // 从本地存储加载状态
    if (localStorage.getItem("sidebar-toggled") === "true") {
      document.body.classList.add("sidebar-toggled")
      document.querySelector(".sidebar").classList.add("toggled")
    }
  }

  // 在小屏幕上自动折叠侧边栏
  const mediaQuery = window.matchMedia("(max-width: 768px)")
  function handleScreenChange(e) {
    if (e.matches) {
      document.body.classList.add("sidebar-toggled")
      document.querySelector(".sidebar").classList.add("toggled")
    }
  }

  // 注册媒体查询监听器
  if (mediaQuery.addEventListener) {
    mediaQuery.addEventListener("change", handleScreenChange)
  } else {
    // 兼容旧版浏览器
    mediaQuery.addListener(handleScreenChange)
  }

  // 初始检查
  handleScreenChange(mediaQuery)
}

/**
 * 初始化加载动画
 */
function initLoadingSpinner() {
  // 创建加载动画元素
  const spinner = document.createElement("div")
  spinner.className = "spinner-overlay"
  spinner.innerHTML = `
        <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;">
            <span class="visually-hidden">加载中...</span>
        </div>
    `

  // 添加到body
  document.body.appendChild(spinner)

  // 隐藏加载动画
  spinner.style.display = "none"

  // 为所有表单添加提交事件
  const forms = document.querySelectorAll("form:not(.no-spinner)")
  forms.forEach((form) => {
    form.addEventListener("submit", () => {
      // 检查表单是否有文件上传
      const hasFileInput = form.querySelector('input[type="file"]') !== null

      // 如果有文件上传或表单有特定类，则显示加载动画
      if (hasFileInput || form.classList.contains("show-spinner")) {
        spinner.style.display = "flex"
      }
    })
  })

  // 为所有下载链接添加点击事件
  const downloadLinks = document.querySelectorAll("a[download]:not(.no-spinner)")
  downloadLinks.forEach((link) => {
    link.addEventListener("click", () => {
      spinner.style.display = "flex"
      setTimeout(() => {
        spinner.style.display = "none"
      }, 2000)
    })
  })

  // 页面加载完成后隐藏加载动画
  window.addEventListener("load", () => {
    spinner.style.display = "none"
  })
}

/**
 * 确认删除对话框
 * @param {string} message - 确认消息
 * @returns {boolean} - 用户确认结果
 */
function confirmDelete(message = "确定要删除吗？此操作不可逆！") {
  return confirm(message)
}

/**
 * 格式化日期时间
 * @param {Date|string} date - 日期对象或日期字符串
 * @param {string} format - 格式化模式
 * @returns {string} - 格式化后的日期字符串
 */
function formatDateTime(date, format = "YYYY-MM-DD HH:mm:ss") {
  const d = new Date(date)

  const year = d.getFullYear()
  const month = String(d.getMonth() + 1).padStart(2, "0")
  const day = String(d.getDate()).padStart(2, "0")
  const hours = String(d.getHours()).padStart(2, "0")
  const minutes = String(d.getMinutes()).padStart(2, "0")
  const seconds = String(d.getSeconds()).padStart(2, "0")

  return format
    .replace("YYYY", year)
    .replace("MM", month)
    .replace("DD", day)
    .replace("HH", hours)
    .replace("mm", minutes)
    .replace("ss", seconds)
}

/**
 * 复制文本到剪贴板
 * @param {string} text - 要复制的文本
 * @returns {Promise<boolean>} - 复制是否成功
 */
function copyToClipboard(text) {
  if (navigator.clipboard) {
    return navigator.clipboard
      .writeText(text)
      .then(() => {
        showToast("复制成功！", "success")
        return true
      })
      .catch((err) => {
        console.error("复制失败:", err)
        showToast("复制失败，请手动复制。", "error")
        return false
      })
  } else {
    // 兼容旧版浏览器
    const textarea = document.createElement("textarea")
    textarea.value = text
    textarea.style.position = "fixed"
    document.body.appendChild(textarea)
    textarea.focus()
    textarea.select()

    try {
      const successful = document.execCommand("copy")
      document.body.removeChild(textarea)

      if (successful) {
        showToast("复制成功！", "success")
        return Promise.resolve(true)
      } else {
        showToast("复制失败，请手动复制。", "error")
        return Promise.resolve(false)
      }
    } catch (err) {
      console.error("复制失败:", err)
      document.body.removeChild(textarea)
      showToast("复制失败，请手动复制。", "error")
      return Promise.resolve(false)
    }
  }
}

/**
 * 显示提示消息
 * @param {string} message - 消息内容
 * @param {string} type - 消息类型 (success, error, warning, info)
 * @param {number} duration - 显示时长(毫秒)
 */
function showToast(message, type = "info", duration = 3000) {
  // 创建toast元素
  const toast = document.createElement("div")
  toast.className = `toast align-items-center text-white bg-${type === "error" ? "danger" : type}`
  toast.setAttribute("role", "alert")
  toast.setAttribute("aria-live", "assertive")
  toast.setAttribute("aria-atomic", "true")

  toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">
                ${message}
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
    `

  // 创建toast容器
  let toastContainer = document.querySelector(".toast-container")
  if (!toastContainer) {
    toastContainer = document.createElement("div")
    toastContainer.className = "toast-container position-fixed bottom-0 end-0 p-3"
    document.body.appendChild(toastContainer)
  }

  // 添加toast到容器
  toastContainer.appendChild(toast)

  // 初始化Bootstrap toast
  const bsToast = new bootstrap.Toast(toast, {
    autohide: true,
    delay: duration,
  })

  // 显示toast
  bsToast.show()

  // 自动移除
  setTimeout(() => {
    toast.remove()
  }, duration + 500)
}

