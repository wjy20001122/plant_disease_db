from django.db import models
from django.contrib.auth.models import AbstractUser

class User(AbstractUser):
    USER_TYPE_CHOICES = (
        ('admin', '超级管理员'),
        ('regular', '普通用户'),
    )
    
    user_type = models.CharField(max_length=10, choices=USER_TYPE_CHOICES, default='regular')
    phone = models.CharField(max_length=15, blank=True, null=True)
    
    def is_admin(self):
        return self.user_type == 'admin'
    
    class Meta:
        verbose_name = '用户'
        verbose_name_plural = '用户'

